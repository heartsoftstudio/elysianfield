#
# Table data for table `item_db`
#
